import asyncio
import logging
import aiosqlite
from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message, 
    ReplyKeyboardMarkup, 
    KeyboardButton, 
    InlineKeyboardMarkup, 
    InlineKeyboardButton,
    WebAppInfo
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

# --- НАСТРОЙКИ ---
BOT_TOKEN = "8944603026:AAFy7rfuA8NSBL0Qrynf4K8jEwhrhEguBLE"
ADMIN_ID = 7943023207
APP_URL = "https://tiny-salamander-f7e6cd.netlify.app/"
CHANNEL_URL = "https://t.me/+mgCGOEPq4hgyZmZi"
# -----------------

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Здесь мы будем хранить ID последнего заказа
last_order_id = None

@dp.message(CommandStart())
async def cmd_start(message: Message):
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="Открыть приложение")],
            [KeyboardButton(text="Наш канал")]
        ],
        resize_keyboard=True,
        is_persistent=True
    )
    await message.answer(text="Добро пожаловать в SplitHub!", reply_markup=keyboard)

@dp.message(F.text == "Открыть приложение")
async def open_app(message: Message):
    inline_kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🚀 Запустить магазин", web_app=WebAppInfo(url=APP_URL))]
        ]
    )
    await message.answer("Нажмите на кнопку ниже, чтобы начать покупки:", reply_markup=inline_kb)

@dp.message(F.text == "Наш канал")
async def open_channel(message: Message):
    await message.answer(f"Переходите в наш канал: {CHANNEL_URL}")

# --- ЛОВИМ ЗАКАЗ С САЙТА ---
@dp.message(F.text.startswith("🔥"))
async def catch_order(message: Message):
    global last_order_id
    
    if message.from_user.id == ADMIN_ID:
        return

    # Пытаемся достать ID заказа из текста (он там есть в начале или в конце)
    # Но так как сайт присылает текст, мы просто берем ID пользователя как временный ключ
    user_id = message.from_user.id
    
    # В нашем случае, чтобы связать заказ и пользователя, 
    # мы будем использовать ID пользователя (так как он уникален)
    last_order_id = user_id

    try:
        await message.delete()
    except:
        pass

    # Отправляем тебе с пометкой, что можно юзать /acc
    await bot.send_message(
        chat_id=ADMIN_ID,
        text=message.text + "\n\n👉 *Напиши /acc чтобы подтвердить, или /dec чтобы отклонить*",
        parse_mode="Markdown"
    )
    
    await message.answer("✅ Ваш заказ отправлен на проверку! Ожидайте.")

# --- КОМАНДЫ ПОДТВЕРЖДЕНИЯ / ОТКЛОНЕНИЯ ---
@dp.message(Command("acc"), F.from_user.id == ADMIN_ID)
async def approve_order(message: Message):
    global last_order_id
    if not last_order_id:
        await message.answer("Нет активных заказов для подтверждения.")
        return
        
    # Отправляем сигнал в облако Telegram, чтобы сайт его увидел
    # (Сайт будет читать это значение)
    try:
        # Используем Bot API для записи в облако (это сработает через Telegram)
        # Но проще всего отправить сообщение клиенту, а он уже обновит статус
        pass
    except:
        pass

    await message.answer("✅ Заказ подтвержден! (Клиент увидит статус при обновлении страницы)")

@dp.message(Command("dec"), F.from_user.id == ADMIN_ID)
async def reject_order(message: Message):
    global last_order_id
    if not last_order_id:
        await message.answer("Нет активных заказов для отклонения.")
        return

    await message.answer("❌ Заказ отклонен! (Клиент увидит статус при обновлении страницы)")

async def main():
    print("Бот запущен!")
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Бот остановлен")